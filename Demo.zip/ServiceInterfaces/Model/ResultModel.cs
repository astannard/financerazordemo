﻿using System;
namespace ServiceInterfaces.Model
{
	public class ResultModel
	{
        public string UserName { get; set; } = "";
        public ProductModel BestProduct { get; set; } 
    }
}

